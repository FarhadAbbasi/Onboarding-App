interface ColorInfo {
  hex: string;
  rgb: [number, number, number];
  luminance: number;
}

interface ColorPalette {
  dominant: string;
  primary: string;
  secondary: string;
  accent: string;
  background: string;
  text: string;
}

export class ColorDetector {
  private static canvas: HTMLCanvasElement | null = null;
  private static ctx: CanvasRenderingContext2D | null = null;

  private static getCanvas(): { canvas: HTMLCanvasElement; ctx: CanvasRenderingContext2D } {
    if (!this.canvas || !this.ctx) {
      this.canvas = document.createElement('canvas');
      this.ctx = this.canvas.getContext('2d', { willReadFrequently: true })!;
    }
    return { canvas: this.canvas, ctx: this.ctx };
  }

  static async detectColorPalette(logoUrl: string, screenshots: string[] = []): Promise<ColorPalette> {
    try {
      // Extract colors from logo
      const logoColors = await this.extractColorsFromImage(logoUrl);
      
      // Extract colors from first screenshot if available
      let screenshotColors: ColorInfo[] = [];
      if (screenshots.length > 0) {
        screenshotColors = await this.extractColorsFromImage(screenshots[0]);
      }

      // Combine and analyze colors
      const allColors = [...logoColors, ...screenshotColors];
      
      // Generate palette
      return this.generatePalette(allColors);
    } catch (error) {
      console.error('Color detection failed:', error);
      // Return default palette
      return {
        dominant: '#3B82F6',
        primary: '#3B82F6',
        secondary: '#10B981',
        accent: '#F59E0B',
        background: '#FFFFFF',
        text: '#1F2937'
      };
    }
  }

  private static async extractColorsFromImage(imageUrl: string): Promise<ColorInfo[]> {
    return new Promise((resolve, reject) => {
      const img = new Image();
      img.crossOrigin = 'anonymous';
      
      img.onload = () => {
        try {
          const { canvas, ctx } = this.getCanvas();
          
          // Set canvas size (sample at lower resolution for performance)
          const maxSize = 100;
          const scale = Math.min(maxSize / img.width, maxSize / img.height);
          canvas.width = img.width * scale;
          canvas.height = img.height * scale;
          
          // Draw image
          ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
          
          // Get image data
          const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
          const pixels = imageData.data;
          
          // Extract colors using k-means clustering
          const colors = this.kMeansClustering(pixels, 5);
          
          resolve(colors);
        } catch (error) {
          reject(error);
        }
      };
      
      img.onerror = () => reject(new Error('Failed to load image'));
      
      // Use proxy for CORS
      img.src = `https://api.allorigins.win/raw?url=${encodeURIComponent(imageUrl)}`;
    });
  }

  private static kMeansClustering(pixels: Uint8ClampedArray, k: number): ColorInfo[] {
    const colors: ColorInfo[] = [];
    const colorCounts = new Map<string, number>();
    
    // Sample pixels (every 10th pixel for performance)
    for (let i = 0; i < pixels.length; i += 40) {
      const r = pixels[i];
      const g = pixels[i + 1];
      const b = pixels[i + 2];
      const a = pixels[i + 3];
      
      // Skip transparent pixels
      if (a < 128) continue;
      
      const key = `${r},${g},${b}`;
      colorCounts.set(key, (colorCounts.get(key) || 0) + 1);
    }
    
    // Sort by frequency and get top colors
    const sortedColors = Array.from(colorCounts.entries())
      .sort((a, b) => b[1] - a[1])
      .slice(0, k * 2);
    
    // Convert to ColorInfo objects
    for (const [colorStr] of sortedColors) {
      const [r, g, b] = colorStr.split(',').map(Number);
      const hex = this.rgbToHex(r, g, b);
      const luminance = this.calculateLuminance(r, g, b);
      
      // Filter out very light or very dark colors for main palette
      if (luminance > 0.1 && luminance < 0.9) {
        colors.push({ hex, rgb: [r, g, b], luminance });
      }
    }
    
    return colors.slice(0, k);
  }

  private static generatePalette(colors: ColorInfo[]): ColorPalette {
    if (colors.length === 0) {
      throw new Error('No colors extracted');
    }
    
    // Sort by luminance
    colors.sort((a, b) => b.luminance - a.luminance);
    
    // Find the most vibrant color for primary
    const vibrantColor = colors.reduce((prev, curr) => {
      const prevSaturation = this.calculateSaturation(prev.rgb);
      const currSaturation = this.calculateSaturation(curr.rgb);
      return currSaturation > prevSaturation ? curr : prev;
    });
    
    // Find contrasting colors
    const darkColor = colors.find(c => c.luminance < 0.3) || colors[colors.length - 1];
    const lightColor = colors.find(c => c.luminance > 0.7) || colors[0];
    
    return {
      dominant: vibrantColor.hex,
      primary: vibrantColor.hex,
      secondary: colors.find(c => c.hex !== vibrantColor.hex)?.hex || this.adjustColor(vibrantColor.hex, -20),
      accent: colors[Math.min(2, colors.length - 1)]?.hex || this.adjustColor(vibrantColor.hex, 30),
      background: lightColor.luminance > 0.9 ? '#FFFFFF' : lightColor.hex,
      text: darkColor.luminance < 0.2 ? '#1F2937' : darkColor.hex
    };
  }

  private static rgbToHex(r: number, g: number, b: number): string {
    return '#' + [r, g, b].map(x => x.toString(16).padStart(2, '0')).join('');
  }

  private static calculateLuminance(r: number, g: number, b: number): number {
    // Relative luminance formula
    const [rs, gs, bs] = [r, g, b].map(c => {
      c = c / 255;
      return c <= 0.03928 ? c / 12.92 : Math.pow((c + 0.055) / 1.055, 2.4);
    });
    return 0.2126 * rs + 0.7152 * gs + 0.0722 * bs;
  }

  private static calculateSaturation(rgb: [number, number, number]): number {
    const [r, g, b] = rgb.map(c => c / 255);
    const max = Math.max(r, g, b);
    const min = Math.min(r, g, b);
    const delta = max - min;
    
    if (max === 0) return 0;
    return delta / max;
  }

  private static adjustColor(hex: string, amount: number): string {
    const num = parseInt(hex.slice(1), 16);
    const r = Math.max(0, Math.min(255, (num >> 16) + amount));
    const g = Math.max(0, Math.min(255, ((num >> 8) & 0x00FF) + amount));
    const b = Math.max(0, Math.min(255, (num & 0x0000FF) + amount));
    return this.rgbToHex(r, g, b);
  }

  static matchToColorScheme(palette: ColorPalette): string {
    // Match detected palette to predefined color schemes
    const schemes = [
      { id: 'ocean-blue', primary: '#3B82F6' },
      { id: 'forest-green', primary: '#10B981' },
      { id: 'sunset-orange', primary: '#F59E0B' },
      { id: 'royal-purple', primary: '#8B5CF6' },
      { id: 'cherry-red', primary: '#EF4444' },
      { id: 'midnight-black', primary: '#1F2937' },
      { id: 'rose-gold', primary: '#EC4899' },
      { id: 'electric-teal', primary: '#14B8A6' }
    ];

    // Find closest match based on color distance
    let closestScheme = schemes[0];
    let minDistance = Infinity;

    for (const scheme of schemes) {
      const distance = this.colorDistance(palette.primary, scheme.primary);
      if (distance < minDistance) {
        minDistance = distance;
        closestScheme = scheme;
      }
    }

    return closestScheme.id;
  }

  private static colorDistance(hex1: string, hex2: string): number {
    const rgb1 = this.hexToRgb(hex1);
    const rgb2 = this.hexToRgb(hex2);
    
    if (!rgb1 || !rgb2) return Infinity;
    
    // Euclidean distance in RGB space
    return Math.sqrt(
      Math.pow(rgb1[0] - rgb2[0], 2) +
      Math.pow(rgb1[1] - rgb2[1], 2) +
      Math.pow(rgb1[2] - rgb2[2], 2)
    );
  }

  private static hexToRgb(hex: string): [number, number, number] | null {
    const result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
    return result ? [
      parseInt(result[1], 16),
      parseInt(result[2], 16),
      parseInt(result[3], 16)
    ] : null;
  }
}